class Reason
{
    [DscProperty()] [String] $Code
    [DscProperty()] [String] $Phrase
}

## Create the reason why the resource is or is not compliant
function Get-MyTargetResource
{
    [CmdletBinding()]
    [OutputType([FileCreate])]
    param
    (
        [Parameter(Mandatory = $true)] [ValidateNotNullOrEmpty()] [String] $Path,
        [Parameter()] [String] $Content
    )

    $testFileContent = $null
    $reasons = [Reason[]]@()

    Write-Verbose -Message "Retrieving test file from the path '$Path'"
    $testFileExists = Test-Path -Path $Path

    if ($testFileExists)
    {
        $testFileContent = Get-Content -Path $Path -Raw
        if ($testFileContent -ne $Content)
        {
            $reason = [Reason]::new()
            $reason.Code   = 'FileContentMismatch'
            $reason.Phrase = "The file content was expected to be: '$Content' but the actual file content is: '$testFileContent'"
            $reasons += $reason
        }
    } else
    {
        $reason = [Reason]::new()
        $reason.Code   = 'FileNotExists'
        $reason.Phrase = "The file does not exist when it was expected to exist at the path '$Path'"
        $reasons += $reason
    }

    if ($reasons.Count -eq 0) 
    {
        $reason = [Reason]::new()
        $reason.Code   = 'Compliant'
        $reason.Phrase = "The file at the '$Path' is compliant."
        $reasons += $reason
    }

    $result = [FileCreate]::new()
    $result.Reasons = $reasons

    Write-Verbose -Message "Finished Get on TestFile"
    return $result
}

Function CreateFolder($path)       # Create the entire Folder path if missing
  { foreach($SubFolder in $path.split('\')) 
    { $foldPath += ($SubFolder+'\'); if (!(Test-Path $foldPath)) { New-Item -ItemType Directory -Path $foldPath } } }

## Perform work.  Return value not required/used
function Set-MyTargetResource
{
    [CmdletBinding()]
    param
    (
        [Parameter(Mandatory = $true)] [ValidateNotNullOrEmpty()] [String] $Path,
        [Parameter()]   [String]  $Content
    )

    Write-Verbose -Message "Starting Set on TestFile"
    Write-Verbose -Message "Parameters`n`tPath:$Path`n`tContent:$Content"
    if ($path.LastIndexOf('\') -eq -1) {$loc=$path.LastIndexOf('/')} else {$loc=$path.LastIndexOf('\')}
    if ($loc -gt 2) {CreateFolder ($Path.Substring(0,$loc)) }  ## extract path of file to create folder
    # Remove-Item $path -Force -ErrorAction SilentlyContinue
    $null = Set-Content -Path $Path -Value $Content -NoNewline -Force
    Write-Verbose -Message "Finished Set on TestFile"
}

## Test xyz.... and return a boolean
function Test-MyTargetResource
{
    [CmdletBinding()]
    [OutputType([bool])]
    param
    (
        [Parameter(Mandatory = $true)]
        [ValidateNotNullOrEmpty()]  [String] $Path,
        [Parameter()]               [String] $Content
    )

    Write-Verbose -Message "Parameters`n`tPath:$Path`n`tContent:$Content"
    $testFileExists = Test-Path -Path $Path
    iF ($testFileExists) {$testFileContent = Get-Content -Path $Path -Raw}
    $testResult = ($testFileExists) -and ($testFileContent -eq $Content)
    Write-Verbose -Message "Finished Test on TestFile"
    return $testResult
}

[DscResource()]
class FileCreate
{
    [DscProperty(Key)] [String] $Path
    [DscProperty()]    [String] $Content
    [DscProperty(NotConfigurable)] [Reason[]] $Reasons
                                                                                                                       # Do not use reserved word hence My
    [FileCreate] Get() { $result = Get-MyTargetResource -Path $this.Path -Content $this.Content; return $Result }  # Get-TargetResource is a reserved word
    [void] Set()       { $null   = Set-MyTargetResource -Path $this.Path -Content $this.Content                 }      # Set-TargetResource is a reserved word
    [bool] Test()      { $result = Test-MyTargetResource -Path $this.Path -Content $this.Content; return $result }     # Test-TargetResource is a reserved word
}
